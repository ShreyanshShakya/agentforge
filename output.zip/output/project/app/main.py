from fastapi import FastAPI
from app.auth.routers.login import router as auth_router
from app.todos.routers.v1.todos import router as todos_router

app = FastAPI()

app.include_router(auth_router)
app.include_router(todos_router)