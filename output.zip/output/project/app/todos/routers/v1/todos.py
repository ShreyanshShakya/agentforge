from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.todos.schemas import TodoCreate, TodoUpdate
from app.todos.models import Todo
from app.todos.crud import create_todo, get_todos, update_todo, delete_todo
from app.dependencies import get_db, get_current_user

router = APIRouter()

@router.post("/todos/", response_model=Todo)
def create_new_todo(todo: TodoCreate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return create_todo(db=db, todo=todo)

@router.get("/todos/", response_model=list[Todo])
def read_todos(skip: int = 0, limit: int = 10, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    todos = get_todos(db=db, skip=skip, limit=limit)
    return todos

@router.put("/todos/{todo_id}", response_model=Todo)
def update_todo_item(todo_id: int, todo_update: TodoUpdate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    todo = get_todo(db=db, todo_id=todo_id)
    if not todo:
        raise HTTPException(status_code=404, detail="Todo not found")
    
    updated_todo = update_todo(db=db, todo_id=todo_id, todo_update=todo_update)
    return updated_todo

@router.delete("/todos/{todo_id}", response_model=dict)
def delete_todo_item(todo_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    result = delete_todo(db=db, todo_id=todo_id)
    if not result:
        raise HTTPException(status_code=404, detail="Todo not found")
    
    return {"message": "Todo deleted successfully"}